export const BardonData = {
  degrees: [
    {
      degreeNumber: 1,
      title: "Elementary Understanding of the Akasha Principle",
      summary: "Foundation of magical training focusing on mental discipline, physical awareness, and elemental balance",
      theoryText: "The first degree introduces the fundamental principles of magic and initiation. Students learn about the nature of the human being as a threefold entity (mental, astral, and physical bodies), the elements and their properties, and the concept of equilibrium. This degree emphasizes the importance of self-knowledge and mental discipline as prerequisites for magical development.",
      practiceText: "Practice includes introspection exercises, developing concentration, basic breathing techniques, and establishing daily magical practices. Students begin to observe their thoughts, emotions, and physical habits while working toward mental and emotional equilibrium through elemental exercises.",
      exercises: [
        {
          id: "1-1",
          title: "Thought Control and Observation",
          description: "Practice observing your thoughts without judgment for increasing periods",
          category: "mental"
        },
        {
          id: "1-2", 
          title: "Character Analysis and Soul Mirror",
          description: "Create detailed lists of your positive and negative traits across all elements",
          category: "mental"
        },
        {
          id: "1-3",
          title: "Physical Awareness Exercises",
          description: "Develop conscious awareness of your physical body through systematic exercises",
          category: "physical"
        },
        {
          id: "1-4",
          title: "Basic Asana Practice",
          description: "Learn to sit comfortably in meditation posture for extended periods",
          category: "physical"
        },
        {
          id: "1-5",
          title: "Pore Breathing Foundation",
          description: "Begin breathing exercises through the pores of the skin",
          category: "astral"
        }
      ]
    },
    {
      degreeNumber: 2,
      title: "Astral Stepping Stone",
      degreeText: "Development of astral senses and deeper elemental work",
      theoryText: "The second degree delves deeper into the nature of the astral body and its functions. Students learn about the astral senses, the akasha principle, and how thoughts and emotions create forms in the astral realm. This degree emphasizes the development of imagination as a magical faculty and introduces more advanced breathing techniques.",
      practiceText: "Exercises focus on developing astral senses through imagination training, advanced breathing techniques, and deeper work with the elements. Students practice astral breathing, develop the ability to evoke sensations, and begin working with elemental accumulation.",
      exercises: [
        {
          id: "2-1",
          title: "Empty Mind Exercise",
          description: "Achieve complete mental silence for increasing durations",
          category: "mental"
        },
        {
          id: "2-2",
          title: "Single Thought Concentration", 
          description: "Focus on one idea or object without mental wandering",
          category: "mental"
        },
        {
          id: "2-3",
          title: "Astral Breathing Exercises",
          description: "Practice breathing light, elements, and vital force through the astral body",
          category: "astral"
        },
        {
          id: "2-4",
          title: "Elemental Sensation Development",
          description: "Evoke and intensify sensations of heat, cold, weight, and lightness",
          category: "astral"
        },
        {
          id: "2-5",
          title: "Morning Cold Bath Training",
          description: "Develop physical and mental resilience through cold water exposure",
          category: "physical"
        },
        {
          id: "2-6",
          title: "Conscious Eating Practice",
          description: "Transform eating into a conscious, magical act",
          category: "physical"
        }
      ]
    },
    {
      degreeNumber: 3,
      title: "Mental Stepping Stone", 
      summary: "Advanced concentration and the development of magical willpower",
      theoryText: "The third degree focuses on developing the mental body and its powers. Students learn about the nature of thought-forms, the power of will, and how to direct mental energy effectively. This degree introduces the concept of projection and the beginning stages of mental travel.",
      practiceText: "Practice involves advanced concentration exercises, thought-form creation, mental projection techniques, and deeper elemental work. Students develop the ability to maintain perfect concentration and begin to project their consciousness to distant locations.",
      exercises: [
        {
          id: "3-1",
          title: "Perfect Thought Control",
          description: "Achieve complete mastery over mental processes and thought direction",
          category: "mental"
        },
        {
          id: "3-2",
          title: "Mental Projection Practice",
          description: "Project consciousness to distant locations while maintaining awareness",
          category: "mental"
        },
        {
          id: "3-3",
          title: "Elemental Accumulation",
          description: "Accumulate specific elements in the body and immediate surroundings",
          category: "astral"
        },
        {
          id: "3-4",
          title: "Biomagnetism Development",
          description: "Develop and project vital force through the hands",
          category: "astral"
        },
        {
          id: "3-5",
          title: "Conscious Retention of Breath",
          description: "Practice advanced breathing retention with elemental accumulation",
          category: "physical"
        }
      ]
    },
    {
      degreeNumber: 4,
      title: "Akasha Principle in Practice",
      summary: "Working with the fifth element and developing akashic consciousness", 
      theoryText: "The fourth degree introduces work with the akasha principle, the fifth element that encompasses and transcends the four material elements. Students learn about akashic consciousness, the nature of space and time, and how to access akashic records.",
      practiceText: "Exercises focus on akasha meditation, developing akashic consciousness, and advanced projection techniques. Students practice working with the akasha principle in all three planes and begin to access higher levels of consciousness.",
      exercises: [
        {
          id: "4-1",
          title: "Akasha Meditation",
          description: "Meditate on the akasha principle and develop akashic consciousness",
          category: "mental"
        },
        {
          id: "4-2",
          title: "Mental Wandering in the Akasha",
          description: "Travel through akashic space while maintaining conscious awareness",
          category: "mental"
        },
        {
          id: "4-3",
          title: "Akashic Breathing",
          description: "Breathe the akasha principle through all three bodies",
          category: "astral"
        },
        {
          id: "4-4",
          title: "Elemental Equilibrium in the Body",
          description: "Create perfect elemental balance in the entire physical form",
          category: "physical"
        },
        {
          id: "4-5",
          title: "Advanced Biomagnetism",
          description: "Project biomagnetism charged with specific elements",
          category: "astral"
        }
      ]
    },
    {
      degreeNumber: 5,
      title: "Mastery Over Space and Time",
      summary: "Transcending temporal limitations and spatial boundaries",
      theoryText: "The fifth degree deals with the mastery of space and time. Students learn how consciousness can transcend normal spatial and temporal limitations, access past and future events, and work with higher dimensional realities.",
      practiceText: "Practice includes time and space transcendence exercises, past and future perception, and advanced consciousness projection. Students develop the ability to perceive events across time and space.",
      exercises: [
        {
          id: "5-1", 
          title: "Past Event Perception",
          description: "Access and observe past events through akashic consciousness",
          category: "mental"
        },
        {
          id: "5-2",
          title: "Future Trend Observation", 
          description: "Perceive potential future developments and their probabilities",
          category: "mental"
        },
        {
          id: "5-3",
          title: "Space-Time Transcendence",
          description: "Experience consciousness beyond normal space-time limitations",
          category: "astral"
        },
        {
          id: "5-4",
          title: "Remote Viewing Practice",
          description: "Accurately perceive distant locations and events",
          category: "astral"
        },
        {
          id: "5-5",
          title: "Temporal Healing Work",
          description: "Work with healing energies across time and space",
          category: "physical"
        }
      ]
    },
    {
      degreeNumber: 6,
      title: "Preparation for Magical Equilibrium", 
      summary: "Achieving perfect balance across all planes of existence",
      theoryText: "The sixth degree focuses on achieving perfect equilibrium across mental, astral, and physical planes. Students learn advanced techniques for balancing opposing forces and preparing for higher magical work.",
      practiceText: "Exercises concentrate on perfect elemental balance, advanced energy work, and preparation for evocation practices. Students develop mastery over all elemental forces within themselves.",
      exercises: [
        {
          id: "6-1",
          title: "Perfect Elemental Equilibrium",
          description: "Achieve complete balance of all elements in all three bodies",
          category: "mental"
        },
        {
          id: "6-2",
          title: "Advanced Element Projection",
          description: "Project pure elemental forces to distant locations",
          category: "astral" 
        },
        {
          id: "6-3",
          title: "Magical Circle Preparation",
          description: "Learn to create and maintain protective magical circles",
          category: "physical"
        },
        {
          id: "6-4",
          title: "Elemental Charging Objects",
          description: "Charge physical objects with specific elemental properties",
          category: "physical"
        },
        {
          id: "6-5",
          title: "Biorhythm Harmonization",
          description: "Harmonize personal biorhythms with natural cycles",
          category: "astral"
        }
      ]
    },
    {
      degreeNumber: 7,
      title: "Development of the Astral Senses",
      summary: "Full activation of clairvoyance, clairaudience, and astral perception",
      theoryText: "The seventh degree focuses on the complete development of astral senses. Students learn to activate clairvoyance, clairaudience, and other psychic abilities through systematic training and elemental work.",
      practiceText: "Practice involves systematic development of each astral sense, protection techniques, and learning to distinguish between different types of astral phenomena. Students develop reliable psychic perception.",
      exercises: [
        {
          id: "7-1",
          title: "Clairvoyance Development",
          description: "Systematically develop clear astral sight and vision",
          category: "astral"
        },
        {
          id: "7-2",
          title: "Clairaudience Training",
          description: "Develop the ability to hear on the astral plane",
          category: "astral"
        },
        {
          id: "7-3",
          title: "Psychometric Practice",
          description: "Read the history and energies of objects through touch",
          category: "astral"
        },
        {
          id: "7-4",
          title: "Astral Perception Discrimination",
          description: "Learn to distinguish between different types of astral phenomena",
          category: "mental"
        },
        {
          id: "7-5",
          title: "Protective Techniques",
          description: "Master protection methods for psychic and astral work",
          category: "physical"
        }
      ]
    },
    {
      degreeNumber: 8,
      title: "Preparation for Magical Practice",
      summary: "Final preparation for advanced magical operations and evocation",
      theoryText: "The eighth degree serves as final preparation for true magical practice. Students learn about magical implements, the hierarchy of spiritual beings, and preparation techniques for advanced magical operations.",
      practiceText: "Exercises focus on creating and consecrating magical implements, advanced protection methods, and preliminary contact with spiritual beings. Students prepare for the advanced practices of degrees 9 and 10.",
      exercises: [
        {
          id: "8-1",
          title: "Magical Implement Creation",
          description: "Create and consecrate personal magical tools and implements",
          category: "physical"
        },
        {
          id: "8-2",
          title: "Advanced Circle Magic",
          description: "Master complex magical circle creation and maintenance",
          category: "astral"
        },
        {
          id: "8-3",
          title: "Spiritual Being Contact Prep",
          description: "Prepare for contact with higher spiritual entities",
          category: "mental"
        },
        {
          id: "8-4",
          title: "Magical Mirror Preparation",
          description: "Create and activate a magical mirror for scrying",
          category: "astral"
        },
        {
          id: "8-5",
          title: "Personal Magical System",
          description: "Develop your unique approach to magical practice",
          category: "mental"
        }
      ]
    },
    {
      degreeNumber: 9,
      title: "Practice with Spiritual Beings",
      summary: "Learning to work with angels, planetary spirits, and other entities",
      theoryText: "The ninth degree introduces practical work with spiritual beings including angels, planetary spirits, and elemental entities. Students learn proper protocols, protection methods, and communication techniques for spiritual contact.",
      practiceText: "Exercises involve systematic contact with various classes of spiritual beings, learning their attributes and areas of influence, and developing working relationships while maintaining proper respect and protection.",
      exercises: [
        {
          id: "9-1",
          title: "Elemental Being Contact",
          description: "Establish contact and communication with elemental entities",
          category: "astral"
        },
        {
          id: "9-2",
          title: "Planetary Spirit Work",
          description: "Work with the spirits of the seven classical planets",
          category: "mental"
        },
        {
          id: "9-3",
          title: "Guardian Angel Communication",
          description: "Develop clear communication with your personal guardian angel",
          category: "astral"
        },
        {
          id: "9-4",
          title: "Evocation Techniques",
          description: "Learn proper methods for evoking spiritual entities",
          category: "physical"
        },
        {
          id: "9-5",
          title: "Spiritual Hierarchy Study",
          description: "Understand the organization and roles of spiritual beings",
          category: "mental"
        }
      ]
    },
    {
      degreeNumber: 10,
      title: "Elevation of Spirit to Higher Planes",
      summary: "Achieving conscious union with higher spiritual realities",
      theoryText: "The tenth and final degree represents the culmination of magical development. Students learn to elevate their consciousness to the highest spiritual planes, achieve union with their higher self, and access the deepest mysteries of existence.",
      practiceText: "Final exercises involve consciousness elevation to spiritual planes, divine union practices, and the ability to work as an intermediary between higher and lower realms. This represents the completion of the first level of true magical initiation.",
      exercises: [
        {
          id: "10-1",
          title: "Higher Self Union",
          description: "Achieve conscious union with your divine higher self",
          category: "mental"
        },
        {
          id: "10-2",
          title: "Divine Plane Ascension",
          description: "Elevate consciousness to the highest spiritual planes",
          category: "astral"
        },
        {
          id: "10-3",
          title: "Universal Love Development",
          description: "Develop unconditional love for all existence",
          category: "mental"
        },
        {
          id: "10-4", 
          title: "Divine Wisdom Integration",
          description: "Integrate higher wisdom into daily consciousness",
          category: "astral"
        },
        {
          id: "10-5",
          title: "Service to Humanity",
          description: "Use developed abilities in service of spiritual evolution",
          category: "physical"
        }
      ]
    }
  ],
  inspirationalQuotes: [
    "The first and most important condition for the student is to be absolutely sure that he really wants to tread this path.",
    "Magic is the highest, most absolute, and most divine knowledge of natural philosophy.",
    "The true magician is made, not born. There is no heredity in magic; it is the result of personal development.",
    "Self-knowledge is the beginning of all wisdom and the foundation of all magical development.",
    "Perfect equilibrium is the basis of all magical work and spiritual development.",
    "The elements are the fundamental forces of creation and must be mastered by every true magician.",
    "Concentration is the key that opens the door to all magical abilities.",
    "Without proper character development, magical abilities become dangerous tools.",
    "The akasha principle is the source from which all elements emerge and to which they return.",
    "True magic is the art of causing changes in accordance with will through natural law.",
    "The highest goal of magical development is union with the Divine.",
    "Patience, perseverance, and absolute faith in success are essential for magical development."
  ]
};