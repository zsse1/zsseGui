import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Progress from 'react-native-progress';

interface DegreeCardProps {
  degree: {
    degreeNumber: number;
    title: string;
    summary: string;
    exercises: any[];
  };
  progress: {
    completion: number;
    exerciseStatus: { [key: string]: boolean };
  };
  onPress: () => void;
}

export const DegreeCard: React.FC<DegreeCardProps> = ({ degree, progress, onPress }) => {
  const completedExercises = Object.values(progress.exerciseStatus).filter(Boolean).length;
  const totalExercises = degree.exercises.length;
  const progressPercentage = totalExercises > 0 ? (completedExercises / totalExercises) : 0;

  return (
    <TouchableOpacity style={styles.container} onPress={onPress} activeOpacity={0.8}>
      <View style={styles.header}>
        <View style={styles.degreeNumber}>
          <Text style={styles.degreeNumberText}>{degree.degreeNumber}</Text>
        </View>
        <View style={styles.titleContainer}>
          <Text style={styles.title} numberOfLines={2}>{degree.title}</Text>
          <Text style={styles.progressText}>
            {completedExercises} of {totalExercises} exercises completed
          </Text>
        </View>
        <View style={styles.statusIcon}>
          {progressPercentage === 1 ? (
            <Ionicons name="checkmark-circle" size={24} color="#32CD32" />
          ) : progressPercentage > 0 ? (
            <Ionicons name="play-circle" size={24} color="#FFD700" />
          ) : (
            <Ionicons name="radio-button-off" size={24} color="#8B7355" />
          )}
        </View>
      </View>

      <Text style={styles.summary} numberOfLines={3}>{degree.summary}</Text>

      <View style={styles.progressContainer}>
        <Progress.Bar
          progress={progressPercentage}
          width={null}
          height={6}
          color="#FFD700"
          unfilledColor="#2a2a4e"
          borderWidth={0}
          borderRadius={3}
        />
        <Text style={styles.percentageText}>{Math.round(progressPercentage * 100)}%</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#1a1a2e',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#2a2a4e',
    shadowColor: '#FFD700',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  degreeNumber: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FFD700',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  degreeNumberText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#0f0f23',
    fontWeight: 'bold',
  },
  titleContainer: {
    flex: 1,
    marginRight: 12,
  },
  title: {
    fontFamily: 'CrimsonText-SemiBold',
    fontSize: 16,
    color: '#FFD700',
    lineHeight: 22,
    marginBottom: 4,
  },
  progressText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#B8860B',
  },
  statusIcon: {
    marginLeft: 8,
  },
  summary: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#E6E6FA',
    lineHeight: 20,
    marginBottom: 16,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  percentageText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 12,
    color: '#FFD700',
    minWidth: 35,
    textAlign: 'right',
  },
});