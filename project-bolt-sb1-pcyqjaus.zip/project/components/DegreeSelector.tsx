import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { TouchableOpacity, Text } from 'react-native';

interface DegreeSelectorProps {
  selectedDegree: number;
  onDegreeSelect: (degree: number) => void;
  degrees: Array<{ degreeNumber: number; title: string }>;
}

export const DegreeSelector: React.FC<DegreeSelectorProps> = ({ 
  selectedDegree, 
  onDegreeSelect, 
  degrees 
}) => {
  return (
    <ScrollView 
      horizontal 
      showsHorizontalScrollIndicator={false}
      style={styles.scrollView}
      contentContainerStyle={styles.container}
    >
      {degrees.map((degree) => (
        <TouchableOpacity
          key={degree.degreeNumber}
          style={[
            styles.degreeButton,
            selectedDegree === degree.degreeNumber && styles.selectedDegreeButton
          ]}
          onPress={() => onDegreeSelect(degree.degreeNumber)}
          activeOpacity={0.8}
        >
          <Text style={[
            styles.degreeButtonText,
            selectedDegree === degree.degreeNumber && styles.selectedDegreeButtonText
          ]}>
            {degree.degreeNumber}
          </Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollView: {
    flexGrow: 0,
  },
  container: {
    flexDirection: 'row',
    paddingHorizontal: 4,
  },
  degreeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#2a2a4e',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 4,
    borderWidth: 1,
    borderColor: '#3a3a6e',
  },
  selectedDegreeButton: {
    backgroundColor: '#FFD700',
    borderColor: '#FFD700',
  },
  degreeButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: '#E6E6FA',
  },
  selectedDegreeButtonText: {
    color: '#0f0f23',
    fontWeight: 'bold',
  },
});