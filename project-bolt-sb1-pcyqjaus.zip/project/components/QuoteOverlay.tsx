import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface QuoteOverlayProps {
  quote: string;
}

export const QuoteOverlay: React.FC<QuoteOverlayProps> = ({ quote }) => {
  return (
    <View style={styles.container}>
      <View style={styles.quoteContainer}>
        <Ionicons name="quote" size={20} color="#DAA520" style={styles.quoteIcon} />
        <Text style={styles.quoteText}>{quote}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 16,
    marginBottom: 24,
  },
  quoteContainer: {
    backgroundColor: 'rgba(26, 26, 46, 0.9)',
    borderRadius: 12,
    padding: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#FFD700',
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  quoteIcon: {
    marginRight: 12,
    marginTop: 2,
  },
  quoteText: {
    fontFamily: 'CrimsonText-Regular',
    fontSize: 14,
    color: '#DAA520',
    fontStyle: 'italic',
    lineHeight: 20,
    flex: 1,
  },
});