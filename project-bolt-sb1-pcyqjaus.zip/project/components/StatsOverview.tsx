import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface StatsOverviewProps {
  stats: {
    totalExercises: number;
    completedExercises: number;
    overallProgress: number;
    currentStreak: number;
  };
}

export const StatsOverview: React.FC<StatsOverviewProps> = ({ stats }) => {
  return (
    <View style={styles.container}>
      <View style={styles.statItem}>
        <View style={styles.statIcon}>
          <Ionicons name="checkmark-done" size={20} color="#32CD32" />
        </View>
        <Text style={styles.statNumber}>{stats.completedExercises}</Text>
        <Text style={styles.statLabel}>Completed</Text>
      </View>
      
      <View style={styles.statItem}>
        <View style={styles.statIcon}>
          <Ionicons name="list" size={20} color="#FFD700" />
        </View>
        <Text style={styles.statNumber}>{stats.totalExercises}</Text>
        <Text style={styles.statLabel}>Total</Text>
      </View>
      
      <View style={styles.statItem}>
        <View style={styles.statIcon}>
          <Ionicons name="flame" size={20} color="#FF4500" />
        </View>
        <Text style={styles.statNumber}>{stats.currentStreak}</Text>
        <Text style={styles.statLabel}>Day Streak</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#1a1a2e',
    borderRadius: 16,
    padding: 20,
    margin: 16,
    borderWidth: 1,
    borderColor: '#2a2a4e',
  },
  statItem: {
    alignItems: 'center',
  },
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#2a2a4e',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  statNumber: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 20,
    color: '#FFD700',
    marginBottom: 4,
  },
  statLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#B8860B',
  },
});