import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface Exercise {
  id: string;
  title: string;
  description: string;
  category: string;
}

interface ExerciseCardProps {
  exercise: Exercise;
  isCompleted: boolean;
  onToggle: () => void;
}

export const ExerciseCard: React.FC<ExerciseCardProps> = ({ exercise, isCompleted, onToggle }) => {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'mental': return 'brain-outline';
      case 'astral': return 'eye-outline';
      case 'physical': return 'body-outline';
      default: return 'ellipse-outline';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'mental': return '#4169E1';
      case 'astral': return '#9370DB';
      case 'physical': return '#DC143C';
      default: return '#FFD700';
    }
  };

  return (
    <TouchableOpacity 
      style={[styles.container, isCompleted && styles.completedContainer]} 
      onPress={onToggle}
      activeOpacity={0.8}
    >
      <View style={styles.header}>
        <View style={styles.leftSection}>
          <View style={[styles.categoryIcon, { backgroundColor: getCategoryColor(exercise.category) }]}>
            <Ionicons 
              name={getCategoryIcon(exercise.category)} 
              size={16} 
              color="white" 
            />
          </View>
          <View style={styles.titleContainer}>
            <Text style={[styles.title, isCompleted && styles.completedTitle]}>
              {exercise.title}
            </Text>
            <Text style={styles.category}>
              {exercise.category.charAt(0).toUpperCase() + exercise.category.slice(1)}
            </Text>
          </View>
        </View>
        
        <TouchableOpacity style={styles.checkbox} onPress={onToggle}>
          {isCompleted ? (
            <Ionicons name="checkmark-circle" size={24} color="#32CD32" />
          ) : (
            <Ionicons name="radio-button-off" size={24} color="#8B7355" />
          )}
        </TouchableOpacity>
      </View>
      
      <Text style={[styles.description, isCompleted && styles.completedDescription]}>
        {exercise.description}
      </Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#2a2a4e',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#3a3a6e',
  },
  completedContainer: {
    backgroundColor: 'rgba(50, 205, 50, 0.1)',
    borderColor: 'rgba(50, 205, 50, 0.3)',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  categoryIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: '#E6E6FA',
    marginBottom: 2,
  },
  completedTitle: {
    textDecorationLine: 'line-through',
    color: '#B8B8B8',
  },
  category: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#B8860B',
  },
  checkbox: {
    padding: 4,
  },
  description: {
    fontFamily: 'Inter-Regular',
    fontSize: 13,
    color: '#D3D3D3',
    lineHeight: 18,
    marginLeft: 44,
  },
  completedDescription: {
    color: '#B8B8B8',
  },
});