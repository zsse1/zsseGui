import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface JournalEntryProps {
  entry: {
    id: string;
    text: string;
    date: string;
  };
  onDelete: () => void;
}

export const JournalEntry: React.FC<JournalEntryProps> = ({ entry, onDelete }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffInHours < 24 * 7) {
      return date.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
    } else {
      return date.toLocaleDateString();
    }
  };

  const confirmDelete = () => {
    Alert.alert(
      'Delete Entry',
      'Are you sure you want to delete this journal entry? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: onDelete }
      ]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.dateContainer}>
          <Ionicons name="calendar-outline" size={16} color="#B8860B" />
          <Text style={styles.date}>{formatDate(entry.date)}</Text>
        </View>
        <TouchableOpacity onPress={confirmDelete} style={styles.deleteButton}>
          <Ionicons name="trash-outline" size={18} color="#DC143C" />
        </TouchableOpacity>
      </View>
      
      <Text style={styles.text}>{entry.text}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#2a2a4e',
    borderLeftWidth: 4,
    borderLeftColor: '#FFD700',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  dateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  date: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#B8860B',
    marginLeft: 6,
  },
  deleteButton: {
    padding: 4,
  },
  text: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#E6E6FA',
    lineHeight: 20,
  },
});