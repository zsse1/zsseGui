import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Progress from 'react-native-progress';

interface ProgressCardProps {
  degree: {
    degreeNumber: number;
    title: string;
  };
  progress: number;
  completedCount: number;
  totalCount: number;
  completionDate?: string;
}

export const ProgressCard: React.FC<ProgressCardProps> = ({
  degree,
  progress,
  completedCount,
  totalCount,
  completionDate
}) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.degreeInfo}>
          <Text style={styles.degreeNumber}>Degree {degree.degreeNumber}</Text>
          <Text style={styles.degreeTitle} numberOfLines={2}>{degree.title}</Text>
        </View>
        {completionDate && (
          <View style={styles.completedBadge}>
            <Ionicons name="checkmark-circle" size={20} color="#32CD32" />
            <Text style={styles.completedText}>Completed</Text>
          </View>
        )}
      </View>

      <View style={styles.progressSection}>
        <View style={styles.progressInfo}>
          <Text style={styles.progressText}>
            {completedCount} of {totalCount} exercises
          </Text>
          <Text style={styles.percentageText}>{Math.round(progress)}%</Text>
        </View>
        
        <Progress.Bar
          progress={progress / 100}
          width={null}
          height={8}
          color="#FFD700"
          unfilledColor="#2a2a4e"
          borderWidth={0}
          borderRadius={4}
          style={styles.progressBar}
        />
        
        {completionDate && (
          <Text style={styles.completionDate}>
            Completed on {formatDate(completionDate)}
          </Text>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#2a2a4e',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  degreeInfo: {
    flex: 1,
  },
  degreeNumber: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 12,
    color: '#B8860B',
    marginBottom: 2,
  },
  degreeTitle: {
    fontFamily: 'CrimsonText-SemiBold',
    fontSize: 14,
    color: '#E6E6FA',
    lineHeight: 18,
  },
  completedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(50, 205, 50, 0.1)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  completedText: {
    fontFamily: 'Inter-Regular',
    fontSize: 10,
    color: '#32CD32',
    marginLeft: 4,
  },
  progressSection: {
    marginTop: 8,
  },
  progressInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  progressText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#D3D3D3',
  },
  percentageText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 12,
    color: '#FFD700',
  },
  progressBar: {
    marginBottom: 8,
  },
  completionDate: {
    fontFamily: 'Inter-Regular',
    fontSize: 11,
    color: '#32CD32',
    textAlign: 'center',
  },
});