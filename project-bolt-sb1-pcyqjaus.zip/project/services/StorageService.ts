import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system';

interface ExerciseStatus {
  [exerciseId: string]: boolean;
}

interface JournalEntry {
  id: string;
  degreeNumber: number;
  text: string;
  date: string;
}

interface UserProgress {
  [degreeNumber: number]: {
    completion: number;
    exerciseStatus: ExerciseStatus;
    completionDate?: string;
    journalEntries: JournalEntry[];
  };
}

const STORAGE_KEYS = {
  USER_PROGRESS: 'bardon_user_progress',
  JOURNAL_ENTRIES: 'bardon_journal_entries',
  SETTINGS: 'bardon_settings',
};

export class StorageService {
  static async getUserProgress(): Promise<UserProgress | null> {
    try {
      const progressData = await AsyncStorage.getItem(STORAGE_KEYS.USER_PROGRESS);
      return progressData ? JSON.parse(progressData) : null;
    } catch (error) {
      console.error('Error getting user progress:', error);
      return null;
    }
  }

  static async saveUserProgress(progress: UserProgress): Promise<void> {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.USER_PROGRESS, JSON.stringify(progress));
    } catch (error) {
      console.error('Error saving user progress:', error);
      throw error;
    }
  }

  static async toggleExerciseCompletion(degreeNumber: number, exerciseId: string): Promise<UserProgress> {
    try {
      const currentProgress = await this.getUserProgress() || {};
      
      if (!currentProgress[degreeNumber]) {
        currentProgress[degreeNumber] = {
          completion: 0,
          exerciseStatus: {},
          journalEntries: []
        };
      }

      const degreeProgress = currentProgress[degreeNumber];
      const isCurrentlyCompleted = degreeProgress.exerciseStatus[exerciseId] || false;
      
      // Toggle completion status
      degreeProgress.exerciseStatus[exerciseId] = !isCurrentlyCompleted;
      
      // Recalculate completion percentage
      const totalExercises = Object.keys(degreeProgress.exerciseStatus).length;
      const completedExercises = Object.values(degreeProgress.exerciseStatus).filter(Boolean).length;
      degreeProgress.completion = totalExercises > 0 ? (completedExercises / totalExercises) * 100 : 0;
      
      // Mark degree as completed if all exercises are done
      if (degreeProgress.completion === 100 && !degreeProgress.completionDate) {
        degreeProgress.completionDate = new Date().toISOString();
      } else if (degreeProgress.completion < 100) {
        delete degreeProgress.completionDate;
      }

      await this.saveUserProgress(currentProgress);
      return currentProgress;
    } catch (error) {
      console.error('Error toggling exercise completion:', error);
      throw error;
    }
  }

  static async getJournalEntries(degreeNumber: number): Promise<JournalEntry[]> {
    try {
      const progress = await this.getUserProgress();
      return progress?.[degreeNumber]?.journalEntries || [];
    } catch (error) {
      console.error('Error getting journal entries:', error);
      return [];
    }
  }

  static async addJournalEntry(degreeNumber: number, entry: JournalEntry): Promise<void> {
    try {
      const currentProgress = await this.getUserProgress() || {};
      
      if (!currentProgress[degreeNumber]) {
        currentProgress[degreeNumber] = {
          completion: 0,
          exerciseStatus: {},
          journalEntries: []
        };
      }

      currentProgress[degreeNumber].journalEntries.unshift(entry);
      await this.saveUserProgress(currentProgress);
    } catch (error) {
      console.error('Error adding journal entry:', error);
      throw error;
    }
  }

  static async deleteJournalEntry(degreeNumber: number, entryId: string): Promise<void> {
    try {
      const currentProgress = await this.getUserProgress() || {};
      
      if (currentProgress[degreeNumber]) {
        currentProgress[degreeNumber].journalEntries = 
          currentProgress[degreeNumber].journalEntries.filter(entry => entry.id !== entryId);
        await this.saveUserProgress(currentProgress);
      }
    } catch (error) {
      console.error('Error deleting journal entry:', error);
      throw error;
    }
  }

  static async exportJournalData(): Promise<void> {
    try {
      const progress = await this.getUserProgress() || {};
      const exportData = {
        exportDate: new Date().toISOString(),
        journalEntries: progress,
      };

      const filename = `bardon_journal_${new Date().toISOString().split('T')[0]}.json`;
      const fileUri = FileSystem.documentDirectory + filename;
      
      await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(exportData, null, 2));
      
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri);
      }
    } catch (error) {
      console.error('Error exporting journal data:', error);
      throw error;
    }
  }

  static async clearAllData(): Promise<void> {
    try {
      await AsyncStorage.multiRemove(Object.values(STORAGE_KEYS));
    } catch (error) {
      console.error('Error clearing all data:', error);
      throw error;
    }
  }

  static async getSettings(): Promise<any> {
    try {
      const settingsData = await AsyncStorage.getItem(STORAGE_KEYS.SETTINGS);
      return settingsData ? JSON.parse(settingsData) : {
        notifications: true,
        reminderTime: '09:00',
        theme: 'dark'
      };
    } catch (error) {
      console.error('Error getting settings:', error);
      return {};
    }
  }

  static async saveSettings(settings: any): Promise<void> {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (error) {
      console.error('Error saving settings:', error);
      throw error;
    }
  }
}