import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { StorageService } from '../../services/StorageService';
import { BardonData } from '../../data/BardonData';
import { ExerciseCard } from '../../components/ExerciseCard';
import { DegreeSelector } from '../../components/DegreeSelector';

export default function ExercisesScreen() {
  const [selectedDegree, setSelectedDegree] = useState(1);
  const [userProgress, setUserProgress] = useState({});

  useEffect(() => {
    loadUserProgress();
  }, []);

  const loadUserProgress = async () => {
    try {
      const progress = await StorageService.getUserProgress();
      setUserProgress(progress || {});
    } catch (error) {
      console.error('Error loading user progress:', error);
    }
  };

  const toggleExerciseCompletion = async (degreeNumber, exerciseId) => {
    try {
      const updatedProgress = await StorageService.toggleExerciseCompletion(degreeNumber, exerciseId);
      setUserProgress(updatedProgress);
    } catch (error) {
      Alert.alert('Error', 'Failed to update exercise progress');
    }
  };

  const currentDegree = BardonData.degrees.find(d => d.degreeNumber === selectedDegree);
  const currentProgress = userProgress[selectedDegree] || { exerciseStatus: {} };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Exercises & Practice</Text>
        <DegreeSelector
          selectedDegree={selectedDegree}
          onDegreeSelect={setSelectedDegree}
          degrees={BardonData.degrees}
        />
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {currentDegree && (
          <View style={styles.degreeSection}>
            <Text style={styles.degreeTitle}>
              Degree {currentDegree.degreeNumber}: {currentDegree.title}
            </Text>
            
            <View style={styles.theorySection}>
              <View style={styles.sectionHeader}>
                <Ionicons name="book-outline" size={20} color="#FFD700" />
                <Text style={styles.sectionTitle}>Theory</Text>
              </View>
              <Text style={styles.theoryText}>{currentDegree.theoryText}</Text>
            </View>

            <View style={styles.practiceSection}>
              <View style={styles.sectionHeader}>
                <Ionicons name="fitness-outline" size={20} color="#FFD700" />
                <Text style={styles.sectionTitle}>Practical Exercises</Text>
              </View>
              <Text style={styles.practiceText}>{currentDegree.practiceText}</Text>
            </View>

            <View style={styles.exercisesSection}>
              <Text style={styles.exercisesTitle}>Exercise Checklist</Text>
              {currentDegree.exercises.map((exercise, index) => (
                <ExerciseCard
                  key={exercise.id}
                  exercise={exercise}
                  isCompleted={currentProgress.exerciseStatus[exercise.id] || false}
                  onToggle={() => toggleExerciseCompletion(selectedDegree, exercise.id)}
                />
              ))}
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f0f23',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#1a1a2e',
    borderBottomWidth: 1,
    borderBottomColor: '#FFD700',
  },
  title: {
    fontFamily: 'CrimsonText-SemiBold',
    fontSize: 24,
    color: '#FFD700',
    textAlign: 'center',
    marginBottom: 16,
  },
  scrollView: {
    flex: 1,
  },
  degreeSection: {
    padding: 20,
  },
  degreeTitle: {
    fontFamily: 'CrimsonText-SemiBold',
    fontSize: 20,
    color: '#FFD700',
    textAlign: 'center',
    marginBottom: 24,
  },
  theorySection: {
    marginBottom: 24,
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#2a2a4e',
  },
  practiceSection: {
    marginBottom: 24,
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#2a2a4e',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#FFD700',
    marginLeft: 8,
  },
  theoryText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#E6E6FA',
    lineHeight: 20,
  },
  practiceText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#E6E6FA',
    lineHeight: 20,
  },
  exercisesSection: {
    marginTop: 8,
  },
  exercisesTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#FFD700',
    marginBottom: 16,
  },
});