import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Progress from 'react-native-progress';
import { StorageService } from '../../services/StorageService';
import { BardonData } from '../../data/BardonData';
import { ProgressCard } from '../../components/ProgressCard';
import { StatsOverview } from '../../components/StatsOverview';

export default function ProgressScreen() {
  const [userProgress, setUserProgress] = useState({});
  const [overallStats, setOverallStats] = useState({
    totalExercises: 0,
    completedExercises: 0,
    overallProgress: 0,
    currentStreak: 0,
  });

  useEffect(() => {
    loadUserProgress();
  }, []);

  const loadUserProgress = async () => {
    try {
      const progress = await StorageService.getUserProgress();
      setUserProgress(progress || {});
      calculateStats(progress || {});
    } catch (error) {
      console.error('Error loading user progress:', error);
    }
  };

  const calculateStats = (progress) => {
    let totalExercises = 0;
    let completedExercises = 0;

    BardonData.degrees.forEach(degree => {
      totalExercises += degree.exercises.length;
      const degreeProgress = progress[degree.degreeNumber];
      if (degreeProgress) {
        completedExercises += Object.values(degreeProgress.exerciseStatus || {}).filter(Boolean).length;
      }
    });

    const overallProgress = totalExercises > 0 ? (completedExercises / totalExercises) * 100 : 0;

    setOverallStats({
      totalExercises,
      completedExercises,
      overallProgress: Math.round(overallProgress),
      currentStreak: calculateStreak(progress),
    });
  };

  const calculateStreak = (progress) => {
    // Simple streak calculation based on recent activity
    // In a real app, you'd track daily activity
    return Math.floor(Math.random() * 15) + 1; // Placeholder
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Your Progress</Text>
        <Text style={styles.subtitle}>Track your journey through the degrees</Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <StatsOverview stats={overallStats} />

        <View style={styles.overallProgressSection}>
          <View style={styles.progressHeader}>
            <Ionicons name="trending-up" size={24} color="#FFD700" />
            <Text style={styles.progressTitle}>Overall Progress</Text>
          </View>
          
          <View style={styles.progressContainer}>
            <Progress.Circle
              size={120}
              progress={overallStats.overallProgress / 100}
              showsText={true}
              color="#FFD700"
              unfilledColor="#2a2a4e"
              borderWidth={0}
              thickness={8}
              textStyle={styles.progressText}
            />
          </View>
          
          <Text style={styles.progressLabel}>
            {overallStats.completedExercises} of {overallStats.totalExercises} exercises completed
          </Text>
        </View>

        <View style={styles.degreesProgressSection}>
          <Text style={styles.sectionTitle}>Progress by Degree</Text>
          {BardonData.degrees.map((degree) => {
            const degreeProgress = userProgress[degree.degreeNumber] || { exerciseStatus: {} };
            const completedCount = Object.values(degreeProgress.exerciseStatus).filter(Boolean).length;
            const totalCount = degree.exercises.length;
            const progressPercentage = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

            return (
              <ProgressCard
                key={degree.degreeNumber}
                degree={degree}
                progress={progressPercentage}
                completedCount={completedCount}
                totalCount={totalCount}
                completionDate={degreeProgress.completionDate}
              />
            );
          })}
        </View>

        <View style={styles.achievementsSection}>
          <View style={styles.achievementsHeader}>
            <Ionicons name="trophy" size={24} color="#FFD700" />
            <Text style={styles.sectionTitle}>Recent Achievements</Text>
          </View>
          
          <View style={styles.achievementsList}>
            <View style={styles.achievementItem}>
              <Ionicons name="checkmark-circle" size={20} color="#32CD32" />
              <Text style={styles.achievementText}>Completed first exercise</Text>
            </View>
            <View style={styles.achievementItem}>
              <Ionicons name="flame" size={20} color="#FF4500" />
              <Text style={styles.achievementText}>7-day practice streak</Text>
            </View>
            <View style={styles.achievementItem}>
              <Ionicons name="star" size={20} color="#FFD700" />
              <Text style={styles.achievementText}>Finished Degree 1</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f0f23',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#1a1a2e',
    borderBottomWidth: 1,
    borderBottomColor: '#FFD700',
  },
  title: {
    fontFamily: 'CrimsonText-SemiBold',
    fontSize: 24,
    color: '#FFD700',
    textAlign: 'center',
    marginBottom: 4,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#B8860B',
    textAlign: 'center',
  },
  scrollView: {
    flex: 1,
  },
  overallProgressSection: {
    alignItems: 'center',
    padding: 24,
    backgroundColor: '#1a1a2e',
    margin: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#2a2a4e',
  },
  progressHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  progressTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#FFD700',
    marginLeft: 8,
  },
  progressContainer: {
    marginVertical: 16,
  },
  progressText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#FFD700',
  },
  progressLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#E6E6FA',
    textAlign: 'center',
  },
  degreesProgressSection: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#FFD700',
    marginBottom: 16,
    paddingLeft: 4,
  },
  achievementsSection: {
    paddingHorizontal: 16,
    marginBottom: 32,
  },
  achievementsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    paddingLeft: 4,
  },
  achievementsList: {
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#2a2a4e',
  },
  achievementItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  achievementText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#E6E6FA',
    marginLeft: 12,
  },
});