import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ImageBackground } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFonts, CrimsonText_400Regular, CrimsonText_600SemiBold } from '@expo-google-fonts/crimson-text';
import { Inter_400Regular, Inter_600SemiBold } from '@expo-google-fonts/inter';
import { StorageService } from '../../services/StorageService';
import { BardonData } from '../../data/BardonData';
import { DegreeCard } from '../../components/DegreeCard';
import { QuoteOverlay } from '../../components/QuoteOverlay';

export default function PathScreen() {
  const [userProgress, setUserProgress] = useState({});
  const [currentQuote, setCurrentQuote] = useState(0);

  const [fontsLoaded, fontError] = useFonts({
    'CrimsonText-Regular': CrimsonText_400Regular,
    'CrimsonText-SemiBold': CrimsonText_600SemiBold,
    'Inter-Regular': Inter_400Regular,
    'Inter-SemiBold': Inter_600SemiBold,
  });

  useEffect(() => {
    loadUserProgress();
    
    // Rotate quotes every 30 seconds
    const quoteInterval = setInterval(() => {
      setCurrentQuote(prev => (prev + 1) % BardonData.inspirationalQuotes.length);
    }, 30000);

    return () => clearInterval(quoteInterval);
  }, []);

  const loadUserProgress = async () => {
    try {
      const progress = await StorageService.getUserProgress();
      setUserProgress(progress || {});
    } catch (error) {
      console.error('Error loading user progress:', error);
    }
  };

  if (!fontsLoaded && !fontError) {
    return null;
  }

  return (
    <View style={styles.container}>
      <ImageBackground
        source={{ uri: 'https://images.pexels.com/photos/956999/milky-way-starry-sky-night-sky-star-956999.jpeg' }}
        style={styles.backgroundImage}
        imageStyle={{ opacity: 0.3 }}
      >
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <Text style={styles.title}>The Path of True Magical Initiation</Text>
            <Text style={styles.subtitle}>Franz Bardon's 10 Degrees</Text>
          </View>

          <QuoteOverlay quote={BardonData.inspirationalQuotes[currentQuote]} />

          <View style={styles.degreesContainer}>
            {BardonData.degrees.map((degree, index) => (
              <DegreeCard
                key={degree.degreeNumber}
                degree={degree}
                progress={userProgress[degree.degreeNumber] || { completion: 0, exerciseStatus: {} }}
                onPress={() => {/* Navigate to degree details */}}
              />
            ))}
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>
              "The first and most important condition for the student is to be absolutely sure that he really wants to tread this path."
            </Text>
            <Text style={styles.footerAuthor}>- Franz Bardon</Text>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f0f23',
  },
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    alignItems: 'center',
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 20,
  },
  title: {
    fontFamily: 'CrimsonText-SemiBold',
    fontSize: 28,
    color: '#FFD700',
    textAlign: 'center',
    marginBottom: 8,
    textShadowColor: 'rgba(0, 0, 0, 0.8)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 4,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#B8860B',
    textAlign: 'center',
  },
  degreesContainer: {
    paddingHorizontal: 16,
    paddingBottom: 20,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 40,
    paddingHorizontal: 20,
    marginTop: 20,
  },
  footerText: {
    fontFamily: 'CrimsonText-Regular',
    fontSize: 16,
    color: '#DAA520',
    textAlign: 'center',
    fontStyle: 'italic',
    lineHeight: 24,
  },
  footerAuthor: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: '#FFD700',
    marginTop: 8,
  },
});