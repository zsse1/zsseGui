import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { StorageService } from '../../services/StorageService';
import { BardonData } from '../../data/BardonData';
import { DegreeSelector } from '../../components/DegreeSelector';
import { JournalEntry } from '../../components/JournalEntry';

export default function JournalScreen() {
  const [selectedDegree, setSelectedDegree] = useState(1);
  const [journalEntries, setJournalEntries] = useState([]);
  const [newEntry, setNewEntry] = useState('');
  const [isAddingEntry, setIsAddingEntry] = useState(false);

  useEffect(() => {
    loadJournalEntries();
  }, [selectedDegree]);

  const loadJournalEntries = async () => {
    try {
      const entries = await StorageService.getJournalEntries(selectedDegree);
      setJournalEntries(entries || []);
    } catch (error) {
      console.error('Error loading journal entries:', error);
    }
  };

  const addJournalEntry = async () => {
    if (!newEntry.trim()) {
      Alert.alert('Error', 'Please enter some text for your journal entry');
      return;
    }

    try {
      const entry = {
        id: Date.now().toString(),
        degreeNumber: selectedDegree,
        text: newEntry.trim(),
        date: new Date().toISOString(),
      };

      await StorageService.addJournalEntry(selectedDegree, entry);
      setJournalEntries(prev => [entry, ...prev]);
      setNewEntry('');
      setIsAddingEntry(false);
    } catch (error) {
      Alert.alert('Error', 'Failed to save journal entry');
    }
  };

  const deleteJournalEntry = async (entryId) => {
    Alert.alert(
      'Delete Entry',
      'Are you sure you want to delete this journal entry?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: async () => {
            try {
              await StorageService.deleteJournalEntry(selectedDegree, entryId);
              setJournalEntries(prev => prev.filter(entry => entry.id !== entryId));
            } catch (error) {
              Alert.alert('Error', 'Failed to delete journal entry');
            }
          }
        }
      ]
    );
  };

  const exportJournal = async () => {
    try {
      await StorageService.exportJournalData();
      Alert.alert('Success', 'Journal exported successfully!');
    } catch (error) {
      Alert.alert('Error', 'Failed to export journal');
    }
  };

  const currentDegree = BardonData.degrees.find(d => d.degreeNumber === selectedDegree);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Personal Journal</Text>
        <View style={styles.headerControls}>
          <DegreeSelector
            selectedDegree={selectedDegree}
            onDegreeSelect={setSelectedDegree}
            degrees={BardonData.degrees}
          />
          <TouchableOpacity style={styles.exportButton} onPress={exportJournal}>
            <Ionicons name="download-outline" size={20} color="#FFD700" />
            <Text style={styles.exportButtonText}>Export</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {currentDegree && (
          <View style={styles.degreeInfo}>
            <Text style={styles.degreeTitle}>
              Degree {currentDegree.degreeNumber}: {currentDegree.title}
            </Text>
            <Text style={styles.degreeDescription}>
              Record your experiences, insights, and progress with the exercises and theory of this degree.
            </Text>
          </View>
        )}

        <View style={styles.addEntrySection}>
          {!isAddingEntry ? (
            <TouchableOpacity 
              style={styles.addButton}
              onPress={() => setIsAddingEntry(true)}
            >
              <Ionicons name="add-circle-outline" size={24} color="#FFD700" />
              <Text style={styles.addButtonText}>Add New Entry</Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.newEntryContainer}>
              <TextInput
                style={styles.textInput}
                placeholder="Write your journal entry here..."
                placeholderTextColor="#8B7355"
                multiline
                numberOfLines={6}
                value={newEntry}
                onChangeText={setNewEntry}
                textAlignVertical="top"
              />
              <View style={styles.entryActions}>
                <TouchableOpacity 
                  style={styles.cancelButton}
                  onPress={() => {
                    setIsAddingEntry(false);
                    setNewEntry('');
                  }}
                >
                  <Text style={styles.cancelButtonText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.saveButton}
                  onPress={addJournalEntry}
                >
                  <Text style={styles.saveButtonText}>Save Entry</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>

        <View style={styles.entriesSection}>
          <Text style={styles.entriesTitle}>
            Your Entries ({journalEntries.length})
          </Text>
          {journalEntries.length === 0 ? (
            <View style={styles.emptyState}>
              <Ionicons name="book-outline" size={48} color="#8B7355" />
              <Text style={styles.emptyStateText}>No journal entries yet</Text>
              <Text style={styles.emptyStateSubtext}>
                Start documenting your magical journey by adding your first entry
              </Text>
            </View>
          ) : (
            journalEntries.map((entry) => (
              <JournalEntry
                key={entry.id}
                entry={entry}
                onDelete={() => deleteJournalEntry(entry.id)}
              />
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f0f23',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#1a1a2e',
    borderBottomWidth: 1,
    borderBottomColor: '#FFD700',
  },
  title: {
    fontFamily: 'CrimsonText-SemiBold',
    fontSize: 24,
    color: '#FFD700',
    textAlign: 'center',
    marginBottom: 16,
  },
  headerControls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  exportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2a2a4e',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#FFD700',
  },
  exportButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 12,
    color: '#FFD700',
    marginLeft: 4,
  },
  scrollView: {
    flex: 1,
  },
  degreeInfo: {
    padding: 20,
    backgroundColor: '#1a1a2e',
    margin: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#2a2a4e',
  },
  degreeTitle: {
    fontFamily: 'CrimsonText-SemiBold',
    fontSize: 18,
    color: '#FFD700',
    marginBottom: 8,
  },
  degreeDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#E6E6FA',
    lineHeight: 20,
  },
  addEntrySection: {
    marginHorizontal: 16,
    marginBottom: 24,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#2a2a4e',
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#FFD700',
    borderStyle: 'dashed',
  },
  addButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#FFD700',
    marginLeft: 8,
  },
  newEntryContainer: {
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#FFD700',
  },
  textInput: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#E6E6FA',
    backgroundColor: '#2a2a4e',
    borderRadius: 8,
    padding: 12,
    minHeight: 120,
    textAlignVertical: 'top',
    borderWidth: 1,
    borderColor: '#3a3a6e',
  },
  entryActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 12,
    gap: 12,
  },
  cancelButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#8B7355',
  },
  cancelButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: '#8B7355',
  },
  saveButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#FFD700',
  },
  saveButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: '#0f0f23',
  },
  entriesSection: {
    paddingHorizontal: 16,
    marginBottom: 32,
  },
  entriesTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#FFD700',
    marginBottom: 16,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 48,
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#2a2a4e',
  },
  emptyStateText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#8B7355',
    marginTop: 16,
  },
  emptyStateSubtext: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#8B7355',
    textAlign: 'center',
    marginTop: 8,
    paddingHorizontal: 32,
  },
});